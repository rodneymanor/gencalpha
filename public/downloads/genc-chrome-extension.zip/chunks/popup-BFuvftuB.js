import{b as m}from"./browser-BwCE-VvP.js";document.querySelector("#app").innerHTML=`
  <div style="font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Helvetica Neue, Arial; padding: 16px; width: 360px; background: #fafafa;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
      <h1 style="font-size: 18px; margin: 0; font-weight: 600; color: #1a1a1a;">GenC Quick Actions</h1>
      <button id="btn-settings" style="padding: 6px 12px; border: 1px solid #ddd; border-radius: 6px; background: white; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.15s ease; display: flex; align-items: center; gap: 6px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="3"></circle>
          <path d="M12 1v6M12 17v6M4.22 4.22l4.24 4.24M15.54 15.54l4.24 4.24M1 12h6M17 12h6M4.22 19.78l4.24-4.24M15.54 8.46l4.24-4.24"></path>
        </svg>
        Settings
      </button>
    </div>
    
    <!-- Video Section -->
    <div id="video-section" style="margin-bottom: 24px; display: none;">
      <h2 style="font-size: 14px; margin: 0 0 12px; font-weight: 500; color: #666;">Add Video to Collection</h2>
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <select id="collection-select" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 8px; background: white; font-size: 14px;">
          <option value="">Select a collection...</option>
        </select>
        <input id="new-collection-input" type="text" placeholder="Or create new collection..." style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px;">
        <button id="btn-add-video" style="padding: 10px 16px; border: none; border-radius: 8px; background: #0081F2; color: white; cursor: pointer; font-weight: 500; transition: all 0.15s ease;">Add Current Video</button>
      </div>
    </div>

    <!-- Creator Section -->
    <div id="creator-section" style="margin-bottom: 24px; display: none;">
      <h2 id="creator-section-title" style="font-size: 14px; margin: 0 0 12px; font-weight: 500; color: #666;">Add Creator to Database</h2>
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <div id="creator-info" style="padding: 8px 12px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;">
          <div style="font-size: 14px; font-weight: 500; color: #495057;" id="creator-username"></div>
          <div style="font-size: 12px; color: #6c757d; margin-top: 2px;" id="creator-platform"></div>
        </div>
        <button id="btn-add-creator" style="padding: 10px 16px; border: none; border-radius: 8px; background: #28a745; color: white; cursor: pointer; font-weight: 500; transition: all 0.15s ease;">Add Creator</button>
      </div>
    </div>

    <!-- Default message when not on a supported page -->
    <div id="default-message" style="padding: 24px 12px; text-align: center; color: #666; font-size: 14px; display: none;">
      <p style="margin: 0 0 8px;">Navigate to a TikTok or Instagram video to add it to your collections.</p>
      <p style="margin: 0; font-size: 13px; color: #999;">You can also visit creator profiles to add them to your database.</p>
    </div>

    <div id="status" style="padding: 8px 12px; font-size: 12px; color: #666; background: #f0f0f0; border-radius: 6px; text-align: center; display: none; margin-top: 16px;"></div>
  </div>
`;const r=(e,o=!1)=>{const t=document.getElementById("status");t.textContent=e,t.style.display="block",t.style.backgroundColor=o?"#fee":"#eff6ff",t.style.color=o?"#c53030":"#2563eb",setTimeout(()=>{t.style.display="none"},2500)},g=async()=>{const{genc_base_url:e,genc_api_key:o}=await m.storage.sync.get(["genc_base_url","genc_api_key"]);let t;return t="https://www.gencapp.pro",{baseUrl:t,apiKey:o}},h=()=>{m.runtime.openOptionsPage()},f=async()=>{const{baseUrl:e,apiKey:o}=await g();if(o)try{const t=await fetch(`${e}/api/chrome-extension/collections`,{method:"GET",headers:{"x-api-key":o}});if(!t.ok)return;const s=(await t.json()).collections||[],n=document.getElementById("collection-select");for(;n.children.length>1;)n.removeChild(n.lastChild);s.forEach(d=>{const l=document.createElement("option");l.value=d.title,l.textContent=d.title,n.appendChild(l)})}catch(t){console.error("Failed to load collections:",t)}},v=async(e,o,t)=>{const{baseUrl:i,apiKey:s}=await g();if(!s)return r("Set API key in Options",!0);try{const n=await fetch(`${i}/api/chrome-extension/collections/add-video`,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":s},body:JSON.stringify({videoUrl:e,collectionTitle:o.trim(),title:t})}),d=await n.json();if(n.ok&&d.success){r(`Added to "${o}"`);const l=document.getElementById("new-collection-input");l.value="";const c=document.getElementById("collection-select");c.selectedIndex=0,setTimeout(()=>f(),500)}else r(d.error||"Failed to add video",!0)}catch(n){console.error("Add video error:",n),r("Failed to add video",!0)}},x=e=>e.includes("youtube.com")||e.includes("youtu.be")?{isVideo:!0,platform:"YouTube"}:e.includes("tiktok.com")?{isVideo:!0,platform:"TikTok"}:e.includes("instagram.com")&&(e.includes("/p/")||e.includes("/reel/")||e.includes("/reels/"))?{isVideo:!0,platform:"Instagram"}:{isVideo:!1,platform:""},w=e=>{const o=e.match(/tiktok\.com\/@([^\/\?]+)/);if(o)return{isCreator:!0,platform:"tiktok",username:o[1]};const t=e.match(/instagram\.com\/([^\/\?]+)\/?$/);if(t&&!e.includes("/p/")&&!e.includes("/reel/")&&!e.includes("/reels/")){const i=t[1];if(!["explore","accounts","stories","direct","tv"].includes(i))return{isCreator:!0,platform:"instagram",username:i}}return{isCreator:!1,platform:"",username:""}},b=async(e,o)=>{const{baseUrl:t,apiKey:i}=await g();if(!i)return r("Set API key in Options",!0);try{const s=await fetch(`${t}/api/chrome-extension/creators/add`,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":i},body:JSON.stringify({username:e.replace("@",""),platform:o.toLowerCase()})}),n=await s.json();s.ok&&n.success?r(`Added @${e} to creators database`):r(n.error||"Failed to add creator",!0)}catch(s){console.error("Add creator error:",s),r("Failed to add creator",!0)}};f();m.tabs.query({active:!0,currentWindow:!0}).then(([e])=>{console.log("Tab info:",e),console.log("Tab URL:",e==null?void 0:e.url);const o=document.getElementById("video-section"),t=document.getElementById("creator-section"),i=document.getElementById("default-message"),s=o.querySelector("h2"),n=document.getElementById("btn-add-video"),d=document.getElementById("creator-section-title"),l=document.getElementById("creator-username");if(document.getElementById("creator-platform"),o.style.display="none",t.style.display="none",i.style.display="none",e!=null&&e.url){console.log("Processing URL:",e.url);const{isVideo:c,platform:p}=x(e.url);if(console.log("Video check result:",{isVideo:c,platform:p}),c)console.log("Showing video section for",p),o.style.display="block",s.textContent=`Add ${p} Video to Collection`,n.textContent=`Add ${p} Video`;else{const{isCreator:y,platform:a,username:u}=w(e.url);console.log("Creator check result:",{isCreator:y,platform:a,username:u}),y?(console.log("Showing creator section for",a,u),t.style.display="block",d.textContent=`Add ${a.charAt(0).toUpperCase()+a.slice(1)} Creator`,l.textContent=`@${u}`,a.textContent=`${a.charAt(0).toUpperCase()+a.slice(1)} Profile`,window.currentCreator={username:u,platform:a}):(console.log("Not on a supported page, showing default message"),i.style.display="block")}}else console.log("No tab URL found, showing default message"),i.style.display="block"}).catch(e=>{console.error("Error querying tab:",e)});document.getElementById("btn-add-video").addEventListener("click",async()=>{const[e]=await m.tabs.query({active:!0,currentWindow:!0}),o=(e==null?void 0:e.url)??"",t=(e==null?void 0:e.title)??"";if(!o){r("No video URL found",!0);return}const{isVideo:i,platform:s}=x(o);if(!i){r("This is not a supported video platform",!0);return}const n=document.getElementById("collection-select"),d=document.getElementById("new-collection-input");let l="";if(d.value.trim())l=d.value.trim();else if(n.value)l=n.value;else{r("Please select or create a collection",!0);return}r(`Adding ${s} video...`),v(o,l,t)});document.getElementById("collection-select").addEventListener("change",()=>{const e=document.getElementById("new-collection-input");e.value=""});document.getElementById("new-collection-input").addEventListener("input",()=>{const e=document.getElementById("collection-select");e.selectedIndex=0});document.getElementById("btn-add-creator").addEventListener("click",async()=>{const e=window.currentCreator;if(!e){r("No creator information found",!0);return}r(`Adding @${e.username}...`),b(e.username,e.platform)});document.getElementById("btn-settings").addEventListener("click",()=>{h()});
